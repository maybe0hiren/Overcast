Reserved for Overcast assets.
